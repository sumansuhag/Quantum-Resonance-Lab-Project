// Wave mathematics utilities for quantum resonance calculations

export interface WaveParams {
  length: number;
  frequency: number;
  velocity: number;
}

export interface HarmonicInfo {
  n: number;
  frequency: number;
  wavelength: number;
  amplitude: number;
}

// Calculate wavelength from frequency and velocity: λ = v/f
export const calculateWavelength = (frequency: number, velocity: number): number => {
  if (frequency === 0) return Infinity;
  return velocity / frequency;
};

// Calculate harmonic number for standing wave: n = 2L/λ
export const calculateHarmonic = (length: number, wavelength: number): number => {
  if (wavelength === 0 || wavelength === Infinity) return 0;
  return (2 * length) / wavelength;
};

// Check if frequency is a harmonic (within tolerance)
export const isHarmonic = (
  length: number,
  frequency: number,
  velocity: number,
  tolerance: number = 0.08
): boolean => {
  const n = calculateHarmonic(length, calculateWavelength(frequency, velocity));
  const nearestInteger = Math.round(n);
  return Math.abs(n - nearestInteger) < tolerance;
};

// Get nearest harmonic number
export const getNearestHarmonic = (
  length: number,
  frequency: number,
  velocity: number
): number => {
  const n = calculateHarmonic(length, calculateWavelength(frequency, velocity));
  return Math.max(1, Math.round(n));
};

// Calculate standing wave amplitude at position x and time t
export const standingWaveAmplitude = (
  x: number,
  length: number,
  n: number,
  amplitude: number,
  time: number
): number => {
  const k = (n * Math.PI) / length;
  const omega = n * Math.PI;
  return amplitude * Math.sin(k * x) * Math.cos(omega * time);
};

// Calculate de Broglie wavelength: λ = h/p
export const deBroglieWavelength = (momentum: number, h: number = 1): number => {
  if (momentum === 0) return Infinity;
  return h / momentum;
};

// Calculate energy level for hydrogen-like atom: E_n = -13.6eV / n²
export const energyLevel = (n: number): number => {
  if (n === 0 || n === Infinity) return 0;
  return -13.6 / (n * n);
};

// Calculate allowed momenta for quantized orbit: p = nh/2πr
export const quantizedMomentum = (n: number, radius: number, h: number = 1): number => {
  if (n === 0 || radius === 0) return 0;
  return (n * h) / (2 * Math.PI * radius);
};

// Calculate wave amplitude on circular orbit at angle θ
export const circularWaveAmplitude = (
  angle: number,
  n: number,
  amplitude: number,
  time: number
): number => {
  return amplitude * Math.cos(n * angle - time);
};