import { useState } from "react";
import { QuantumToggle } from "./components/QuantumToggle";
import { StandingWave } from "./components/StandingWave";
import { OrbitWave } from "./components/OrbitWave";

function App() {
  const [isQuantized, setIsQuantized] = useState(false);
  const [frequency, setFrequency] = useState(1.5);
  const [stringLength, setStringLength] = useState(180);
  const [momentum, setMomentum] = useState(1.5);
  const [orbitRadius, setOrbitRadius] = useState(50);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100">
      <header className="border-b border-slate-800 py-6 px-4">
        <div className="max-w-6xl mx-auto">
          <h1 className="text-3xl font-bold text-center bg-gradient-to-r from-cyan-400 to-amber-300 bg-clip-text text-transparent">
            Quantum Resonance Lab
          </h1>
          <p className="text-center text-slate-400 mt-2">
            Quantization emerges when waves meet boundaries
          </p>
        </div>
      </header>

      <main className="max-w-6xl mx-auto px-4 py-8">
        <QuantumToggle isQuantized={isQuantized} onToggle={() => setIsQuantized(!isQuantized)} />

        <div className="grid md:grid-cols-2 gap-8 mt-6">
          <StandingWave
            isQuantized={isQuantized}
            frequency={frequency}
            onFrequencyChange={setFrequency}
            length={stringLength}
            onLengthChange={setStringLength}
          />

          <OrbitWave
            isQuantized={isQuantized}
            momentum={momentum}
            onMomentumChange={setMomentum}
            radius={orbitRadius}
            onRadiusChange={setOrbitRadius}
          />
        </div>

        <div className="mt-12 text-center">
          <div className="inline-block bg-slate-900 border border-slate-800 rounded-lg p-6 max-w-2xl">
            <h2 className="text-lg font-semibold text-cyan-400 mb-3">
              The Core Insight
            </h2>
            <p className="text-slate-300 text-sm leading-relaxed">
              In <span className="text-cyan-400">classical</span> physics, waves can have any frequency.
              But when a wave is confined by boundaries (like a string fixed at both ends, or an electron
              orbiting a nucleus), only waves that{" "}
              <span className="text-amber-300">fit perfectly</span> survive. These are the{" "}
              <span className="text-amber-300">quantized states</span> — discrete energy levels that
              give rise to atomic structure and spectral lines.
            </p>
            <div className="mt-4 pt-4 border-t border-slate-800">
              <p className="text-slate-500 text-xs italic">
                Toggle between modes above to see how the same mathematics explains both
                guitar strings and atoms.
              </p>
            </div>
          </div>
        </div>
      </main>

      <footer className="border-t border-slate-800 py-6 px-4 mt-12">
        <div className="max-w-6xl mx-auto text-center text-slate-500 text-sm">
          Quantization is not magic. It's geometry.
        </div>
      </footer>
    </div>
  );
}

export default App;