import { useState, useEffect, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Label } from "../components/ui/label";
import {
  calculateWavelength,
  calculateHarmonic,
  isHarmonic,
  standingWaveAmplitude,
} from "../utils/waveMath";

interface StandingWaveProps {
  isQuantized: boolean;
  frequency: number;
  onFrequencyChange: (value: number) => void;
  length: number;
  onLengthChange: (value: number) => void;
}

export function StandingWave({
  isQuantized,
  frequency,
  onFrequencyChange,
  length,
  onLengthChange,
}: StandingWaveProps) {
  const [time, setTime] = useState(0);
  const [amplitude, setAmplitude] = useState(1);
  const animationRef = useRef<number>();

  const velocity = 100;
  const wavelength = calculateWavelength(frequency, velocity);
  const harmonic = calculateHarmonic(length, wavelength);
  const nearestHarmonic = Math.round(harmonic);
  const isStable = isHarmonic(length, frequency, velocity);

  useEffect(() => {
    const animate = () => {
      setTime((t) => t + 0.08);
      animationRef.current = requestAnimationFrame(animate);
    };
    animationRef.current = requestAnimationFrame(animate);
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (isQuantized) {
      const targetAmplitude = isStable ? 1 : 0.15;
      setAmplitude((prev) => prev + (targetAmplitude - prev) * 0.08);
    } else {
      setAmplitude(1);
    }
  }, [isQuantized, isStable]);

  const points = [];
  const numPoints = 200;
  for (let i = 0; i <= numPoints; i++) {
    const x = (i / numPoints) * length;
    const y = standingWaveAmplitude(x, length, harmonic, amplitude * 40, time);
    points.push({ x, y });
  }

  const pathData = points
    .map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${100 - p.y}`)
    .join(" ");

  return (
    <Card className="bg-slate-900 border-slate-800">
      <CardHeader>
        <CardTitle className="text-slate-100">Standing Wave (String)</CardTitle>
        <CardDescription className="text-slate-400">
          Fixed at both ends — only certain wavelengths fit
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="relative bg-slate-950 rounded-lg p-4 h-48">
          <svg className="w-full h-full" viewBox={`0 0 ${length + 24} 200`}>
            <path
              d={pathData}
              fill="none"
              stroke={
                isQuantized && isStable ? "rgb(253, 224, 71)" : "rgb(34, 211, 238)"
              }
              strokeWidth="3"
              strokeLinecap="round"
              className={
                isQuantized && isStable ? "drop-shadow-[0_0_10px_rgba(253,224,71,0.6)]" : ""
              }
            />
            <circle cx="12" cy="100" r="6" fill="rgb(148, 163, 184)" />
            <circle cx={length + 12} cy="100" r="6" fill="rgb(148, 163, 184)" />
            <line
              x1="0"
              y1="100"
              x2={length + 24}
              y2="100"
              stroke="rgb(51, 65, 85)"
              strokeWidth="1"
              strokeDasharray="4"
            />
          </svg>
        </div>

        <div className="space-y-4">
          <div>
            <Label className="text-slate-300">String Length (L)</Label>
            <input
              type="range"
              min="100"
              max="280"
              step="10"
              value={length}
              onChange={(e) => onLengthChange(Number(e.target.value))}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500 mt-2"
            />
            <div className="flex justify-between text-sm text-slate-500 mt-1">
              <span>100</span>
              <span className="text-cyan-400 font-mono">{length.toFixed(0)}</span>
              <span>280</span>
            </div>
          </div>

          <div>
            <Label className="text-slate-300">Frequency (f)</Label>
            <input
              type="range"
              min="0.3"
              max="4"
              step="0.05"
              value={frequency}
              onChange={(e) => onFrequencyChange(Number(e.target.value))}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500 mt-2"
            />
            <div className="flex justify-between text-sm text-slate-500 mt-1">
              <span>0.3</span>
              <span className="text-cyan-400 font-mono">{frequency.toFixed(2)}</span>
              <span>4.0</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-950 rounded-lg p-4 space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-slate-400 text-sm">Wavelength:</span>
            <span className="font-mono text-cyan-400">λ = {wavelength.toFixed(1)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-400 text-sm">Harmonic:</span>
            <span
              className={`font-mono ${
                isQuantized && isStable ? "text-amber-300" : "text-slate-300"
              }`}
            >
              n = {harmonic.toFixed(2)}
            </span>
          </div>
          <div className="text-center pt-2 border-t border-slate-800">
            <span className="font-mono text-sm text-slate-400">
              f<sub className="text-xs">n</sub> = n · v / (2L)
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}