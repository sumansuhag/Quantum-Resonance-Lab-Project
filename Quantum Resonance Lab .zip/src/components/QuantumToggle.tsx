import { Button } from "../components/ui/button";

interface QuantumToggleProps {
  isQuantized: boolean;
  onToggle: () => void;
}

export function QuantumToggle({ isQuantized, onToggle }: QuantumToggleProps) {
  return (
    <div className="flex items-center justify-center gap-4 py-4">
      <span
        className={`text-sm font-medium transition-colors duration-300 ${
          !isQuantized ? "text-cyan-400" : "text-slate-500"
        }`}
      >
        Classical Continuum
      </span>
      
      <Button
        onClick={onToggle}
        variant="outline"
        className={`
          relative w-16 h-8 rounded-full p-1 transition-all duration-300
          ${isQuantized ? "bg-cyan-600 border-cyan-500" : "bg-slate-700 border-slate-600"}
        `}
      >
        <div
          className={`
            w-6 h-6 rounded-full bg-white shadow-md transition-all duration-300
            ${isQuantized ? "translate-x-8" : "translate-x-0"}
            ${isQuantized ? "shadow-cyan-500/50" : ""}
          `}
        />
      </Button>
      
      <span
        className={`text-sm font-medium transition-colors duration-300 ${
          isQuantized ? "text-amber-300" : "text-slate-500"
        }`}
      >
        Quantized States
      </span>
    </div>
  );
}