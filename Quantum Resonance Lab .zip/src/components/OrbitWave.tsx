import { useState, useEffect, useRef } from "react";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "../components/ui/card";
import { Label } from "../components/ui/label";
import {
  deBroglieWavelength,
  calculateHarmonic,
  isHarmonic,
  circularWaveAmplitude,
  quantizedMomentum,
  energyLevel,
} from "../utils/waveMath";

interface OrbitWaveProps {
  isQuantized: boolean;
  momentum: number;
  onMomentumChange: (value: number) => void;
  radius: number;
  onRadiusChange: (value: number) => void;
}

export function OrbitWave({
  isQuantized,
  momentum,
  onMomentumChange,
  radius,
  onRadiusChange,
}: OrbitWaveProps) {
  const [time, setTime] = useState(0);
  const [amplitude, setAmplitude] = useState(1);
  const animationRef = useRef<number>();

  const h = 1;
  const wavelength = deBroglieWavelength(momentum, h);
  const circumference = 2 * Math.PI * radius;
  const harmonic = calculateHarmonic(circumference, wavelength);
  const nearestHarmonic = Math.round(harmonic);
  const isStable = isHarmonic(circumference, momentum, momentum, 0.1);

  useEffect(() => {
    const animate = () => {
      setTime((t) => t + 0.06);
      animationRef.current = requestAnimationFrame(animate);
    };
    animationRef.current = requestAnimationFrame(animate);
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, []);

  useEffect(() => {
    if (isQuantized) {
      const targetAmplitude = isStable ? 1 : 0.1;
      setAmplitude((prev) => prev + (targetAmplitude - prev) * 0.08);
    } else {
      setAmplitude(1);
    }
  }, [isQuantized, isStable]);

  const centerX = 150;
  const centerY = 120;
  const orbitRadius = radius;

  const wavePoints = [];
  const numPoints = 180;
  for (let i = 0; i <= numPoints; i++) {
    const angle = (i / numPoints) * 2 * Math.PI;
    const waveAmp = circularWaveAmplitude(angle, harmonic, amplitude * 15, time);
    const r = orbitRadius + waveAmp;
    const x = centerX + r * Math.cos(angle);
    const y = centerY + r * Math.sin(angle);
    wavePoints.push({ x, y });
  }

  const wavePath = wavePoints
    .map((p, i) => `${i === 0 ? "M" : "L"} ${p.x} ${p.y}`)
    .join(" ");

  const orbitPath = `M ${centerX + orbitRadius} ${centerY} A ${orbitRadius} ${orbitRadius} 0 1 1 ${centerX - orbitRadius} ${centerY} A ${orbitRadius} ${orbitRadius} 0 1 1 ${centerX + orbitRadius} ${centerY}`;

  const energyLevels = [1, 2, 3, 4, 5].map((n) => ({
    n,
    energy: energyLevel(n),
    radius: n * 20,
  }));

  return (
    <Card className="bg-slate-900 border-slate-800">
      <CardHeader>
        <CardTitle className="text-slate-100">Electron Orbit Wave</CardTitle>
        <CardDescription className="text-slate-400">
          de Broglie wave — only integer wraps survive
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="relative bg-slate-950 rounded-lg p-4 h-64">
          <svg className="w-full h-full" viewBox="0 0 300 240">
            {isQuantized && (
              <>
                {energyLevels.map((level) => (
                  <circle
                    key={level.n}
                    cx={centerX}
                    cy={centerY}
                    r={level.radius}
                    fill="none"
                    stroke="rgb(71, 85, 105)"
                    strokeWidth="1"
                    strokeDasharray="3"
                    opacity={0.5}
                  />
                ))}
              </>
            )}
            <path
              d={orbitPath}
              fill="none"
              stroke="rgb(71, 85, 105)"
              strokeWidth="1"
              strokeDasharray="4"
            />
            <path
              d={wavePath}
              fill="none"
              stroke={
                isQuantized && isStable ? "rgb(253, 224, 71)" : "rgb(34, 211, 238)"
              }
              strokeWidth="2.5"
              strokeLinecap="round"
              strokeLinejoin="round"
              className={
                isQuantized && isStable ? "drop-shadow-[0_0_8px_rgba(253,224,71,0.5)]" : ""
              }
            />
            <circle cx={centerX} cy={centerY} r="8" fill="rgb(251, 146, 60)" />
            <text
              x={centerX}
              y={centerY + 4}
              textAnchor="middle"
              className="text-xs fill-slate-950 font-bold"
            >
              +
            </text>
          </svg>
        </div>

        <div className="space-y-4">
          <div>
            <Label className="text-slate-300">Orbit Radius (r)</Label>
            <input
              type="range"
              min="30"
              max="70"
              step="2"
              value={radius}
              onChange={(e) => onRadiusChange(Number(e.target.value))}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500 mt-2"
            />
            <div className="flex justify-between text-sm text-slate-500 mt-1">
              <span>30</span>
              <span className="text-cyan-400 font-mono">{radius.toFixed(0)}</span>
              <span>70</span>
            </div>
          </div>

          <div>
            <Label className="text-slate-300">Momentum (p)</Label>
            <input
              type="range"
              min="0.5"
              max="5"
              step="0.05"
              value={momentum}
              onChange={(e) => onMomentumChange(Number(e.target.value))}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-cyan-500 mt-2"
            />
            <div className="flex justify-between text-sm text-slate-500 mt-1">
              <span>0.5</span>
              <span className="text-cyan-400 font-mono">{momentum.toFixed(2)}</span>
              <span>5.0</span>
            </div>
          </div>
        </div>

        <div className="bg-slate-950 rounded-lg p-4 space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-slate-400 text-sm">de Broglie λ:</span>
            <span className="font-mono text-cyan-400">λ = {wavelength.toFixed(2)}</span>
          </div>
          <div className="flex justify-between items-center">
            <span className="text-slate-400 text-sm">Wraps (n):</span>
            <span
              className={`font-mono ${
                isQuantized && isStable ? "text-amber-300" : "text-slate-300"
              }`}
            >
              n = {harmonic.toFixed(2)}
            </span>
          </div>
          <div className="text-center pt-2 border-t border-slate-800 space-y-1">
            <span className="font-mono text-sm text-slate-400 block">
              n · λ = 2πr
            </span>
            <span className="font-mono text-sm text-slate-400 block">
              λ = h / p
            </span>
          </div>
        </div>

        {isQuantized && (
          <div className="bg-slate-950 rounded-lg p-4">
            <div className="text-slate-400 text-sm mb-3 text-center">
              Energy Levels
            </div>
            <div className="flex justify-center gap-2">
              {[1, 2, 3, 4, 5].map((n) => (
                <div
                  key={n}
                  className={`
                    px-3 py-2 rounded text-center transition-all duration-300
                    ${
                      nearestHarmonic === n
                        ? "bg-amber-500/20 border border-amber-400 text-amber-300"
                        : "bg-slate-800 border border-slate-700 text-slate-500"
                    }
                  `}
                >
                  <div className="font-mono text-sm">E{n}</div>
                  <div className="text-xs">{energyLevel(n).toFixed(1)} eV</div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}